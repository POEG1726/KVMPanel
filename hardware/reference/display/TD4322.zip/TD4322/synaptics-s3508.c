// SPDX-License-Identifier: GPL-2.0-only
/*
 * Synaptics S3508 RMI4 touchscreen driver.
 *
 * This is a small mainline-style I2C input driver derived from the common
 * S3508 path used by the local MCU port and the OnePlus/Oppo Android driver:
 * F01 handles device control/interrupts, F12 reports multi-touch objects.
 *
 * 重点寄存器/区域：
 * - 0xff：RMI4 page select，本驱动只使用 page 0。
 * - PDT：page 0 的 0xe9..0x05，每 6 字节一个 function descriptor。
 * - F01：RMI device control/status function，用于 normal mode、清中断、开中断。
 * - F12：2D touch function，用于读取 object attention 和每个触点的 8 字节数据。
 * - F12 Data + 0x03：object attention，两字节，低 10 bit 对应 slot0..slot9。
 *
 * 初始化流程：
 * 1. 打开 vdd/vio，可选释放 reset。
 * 2. 写 0xff = 0x00，切到 RMI page 0。
 * 3. 扫描 PDT，找到 F01/F12 的 query/cmd/control/data base。
 * 4. 写 F01 Ctrl0 = 0x80，让 IC 进入 normal operation。
 * 5. 读取 F01 Data 清掉上电遗留中断。
 * 6. 写 F01 Ctrl1 = 0x7f，使能绝对坐标相关中断。
 * 7. 注册 threaded IRQ，在 IRQ 线程里读取 F12 数据并上报 input MT slot。
 */

#include <linux/delay.h>
#include <linux/gpio/consumer.h>
#include <linux/i2c.h>
#include <linux/input.h>
#include <linux/input/mt.h>
#include <linux/input/touchscreen.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/of.h>
#include <linux/pm.h>
#include <linux/property.h>
#include <linux/regulator/consumer.h>

#define S3508_NAME			"synaptics-s3508"

/* S3508 is an RMI4 device. Page 0 contains F01/F12 descriptors. */
#define S3508_PAGE_SELECT		0xff
#define S3508_PAGE_0			0x00

/* RMI4 Product Descriptor Table layout. */
#define S3508_PDT_START			0xe9
#define S3508_PDT_END			0x05
#define S3508_PDT_ENTRY_SIZE		6
#define S3508_PDT_FUNC_NUMBER		5
#define S3508_RMI_F01			0x01
#define S3508_RMI_F12			0x12

/* F01 control/data offsets used by vendor code and the local MCU port. */
#define S3508_F01_DEVICE_CONTROL	0x00
#define S3508_F01_INTERRUPT_ENABLE	0x01
#define S3508_F01_NORMAL_OPERATION	0x80
#define S3508_F01_ENABLE_ABS_IRQS	0x7f

/* F12 object attention lives at Data + 3, two bytes, low 10 bits used. */
#define S3508_F12_OBJECT_ATTENTION	0x03
#define S3508_F12_OBJECT_MASK		0x03ff

#define S3508_MAX_CONTACTS		10
#define S3508_CONTACT_SIZE		8

struct s3508_fn_desc {
	/* RMI4 function descriptor 的前 4 字节分别是各 base 地址。 */
	u8 query_base;
	u8 cmd_base;
	u8 ctrl_base;
	u8 data_base;
};

struct s3508_data {
	struct i2c_client *client;
	struct input_dev *input;
	struct touchscreen_properties prop;
	struct gpio_desc *reset_gpio;
	struct regulator *vdd;
	struct regulator *vio;
	struct mutex lock;

	struct s3508_fn_desc f01;
	struct s3508_fn_desc f12;
	unsigned int max_contacts;
	bool powered;
	bool suspended;
};

static int s3508_set_page(struct s3508_data *ts, u8 page)
{
	/* S3508/RMI4 使用 0xff 选择寄存器页。 */
	return i2c_smbus_write_byte_data(ts->client, S3508_PAGE_SELECT, page);
}

static int s3508_read_block(struct s3508_data *ts, u8 reg, void *buf, size_t len)
{
	struct i2c_client *client = ts->client;
	struct i2c_msg msg[2];
	int ret;

	/* F12 触点块最长 80 字节，超过 SMBus block 常见 32 字节限制。 */
	msg[0].addr = client->addr;
	msg[0].flags = 0;
	msg[0].len = 1;
	msg[0].buf = &reg;

	msg[1].addr = client->addr;
	msg[1].flags = I2C_M_RD;
	msg[1].len = len;
	msg[1].buf = buf;

	ret = i2c_transfer(client->adapter, msg, ARRAY_SIZE(msg));
	if (ret != ARRAY_SIZE(msg))
		return ret < 0 ? ret : -EIO;

	return 0;
}

static int s3508_write_u8(struct s3508_data *ts, u8 reg, u8 val)
{
	return i2c_smbus_write_byte_data(ts->client, reg, val);
}

static int s3508_read_f01_status(struct s3508_data *ts)
{
	u8 status[4];

	/* 读取 F01 Data 可清除锁存中断，避免低有效 INT 一直保持低电平。 */
	return s3508_read_block(ts, ts->f01.data_base, status, sizeof(status));
}

static int s3508_scan_pdt(struct s3508_data *ts)
{
	u8 desc[S3508_PDT_ENTRY_SIZE];
	int addr;
	int ret;

	ret = s3508_set_page(ts, S3508_PAGE_0);
	if (ret < 0)
		return ret;

	memset(&ts->f01, 0, sizeof(ts->f01));
	memset(&ts->f12, 0, sizeof(ts->f12));

	for (addr = S3508_PDT_START; addr >= S3508_PDT_END;
	     addr -= S3508_PDT_ENTRY_SIZE) {
		ret = s3508_read_block(ts, addr, desc, sizeof(desc));
		if (ret < 0)
			return ret;

		/* function number 为 0 表示 PDT 结束。 */
		if (desc[S3508_PDT_FUNC_NUMBER] == 0x00)
			break;

		switch (desc[S3508_PDT_FUNC_NUMBER]) {
		case S3508_RMI_F01:
			ts->f01.query_base = desc[0];
			ts->f01.cmd_base = desc[1];
			ts->f01.ctrl_base = desc[2];
			ts->f01.data_base = desc[3];
			break;
		case S3508_RMI_F12:
			ts->f12.query_base = desc[0];
			ts->f12.cmd_base = desc[1];
			ts->f12.ctrl_base = desc[2];
			ts->f12.data_base = desc[3];
			break;
		}

		if (ts->f01.data_base && ts->f12.data_base)
			break;
	}

	if (!ts->f01.data_base || !ts->f12.data_base)
		return -ENODEV;

	dev_dbg(&ts->client->dev,
		"F01 q/c/ctl/d=%02x/%02x/%02x/%02x F12 q/c/ctl/d=%02x/%02x/%02x/%02x\n",
		ts->f01.query_base, ts->f01.cmd_base,
		ts->f01.ctrl_base, ts->f01.data_base,
		ts->f12.query_base, ts->f12.cmd_base,
		ts->f12.ctrl_base, ts->f12.data_base);

	return 0;
}

static int s3508_hw_power_on(struct s3508_data *ts)
{
	int ret;

	if (ts->powered)
		return 0;

	/* 电源名由 DTS 中的 vdd-supply / vio-supply 提供，二者都可选。 */
	if (ts->vdd) {
		ret = regulator_enable(ts->vdd);
		if (ret)
			return ret;
	}

	if (ts->vio) {
		ret = regulator_enable(ts->vio);
		if (ret)
			goto disable_vdd;
	}

	msleep(5);

	if (ts->reset_gpio) {
		/* gpiod 使用逻辑值：1 表示 assert reset，0 表示 release reset。 */
		gpiod_set_value_cansleep(ts->reset_gpio, 1);
		usleep_range(10000, 11000);
		gpiod_set_value_cansleep(ts->reset_gpio, 0);
		msleep(100);
	}

	ts->powered = true;

	return 0;

disable_vdd:
	if (ts->vdd)
		regulator_disable(ts->vdd);
	return ret;
}

static void s3508_hw_power_off(struct s3508_data *ts)
{
	if (!ts->powered)
		return;

	if (ts->reset_gpio)
		gpiod_set_value_cansleep(ts->reset_gpio, 1);

	if (ts->vio)
		regulator_disable(ts->vio);
	if (ts->vdd)
		regulator_disable(ts->vdd);

	ts->powered = false;
}

static int s3508_init_device(struct s3508_data *ts)
{
	int ret;

	/* 每次上电或 resume 后都重新扫描 PDT，避免 soft reset 后 base 失效。 */
	ret = s3508_scan_pdt(ts);
	if (ret < 0)
		return ret;

	ret = s3508_set_page(ts, S3508_PAGE_0);
	if (ret < 0)
		return ret;

	/* F01 Ctrl0 = 0x80：normal operation，和本地/OPPO 驱动一致。 */
	ret = s3508_write_u8(ts, ts->f01.ctrl_base + S3508_F01_DEVICE_CONTROL,
			     S3508_F01_NORMAL_OPERATION);
	if (ret < 0)
		return ret;

	/* 开中断前先清掉旧状态，避免 probe 后立刻收到伪中断。 */
	s3508_read_f01_status(ts);

	/* F01 Ctrl1 = 0x7f：使能绝对坐标相关 interrupt status bits。 */
	ret = s3508_write_u8(ts, ts->f01.ctrl_base + S3508_F01_INTERRUPT_ENABLE,
			     S3508_F01_ENABLE_ABS_IRQS);
	if (ret < 0)
		return ret;

	return s3508_read_f01_status(ts);
}

static void s3508_report_release(struct s3508_data *ts)
{
	unsigned int i;

	/* 没有 object attention 时，显式释放所有 Type-B slots。 */
	for (i = 0; i < ts->max_contacts; i++) {
		input_mt_slot(ts->input, i);
		input_mt_report_slot_state(ts->input, MT_TOOL_FINGER, false);
	}

	input_mt_sync_frame(ts->input);
	input_sync(ts->input);
}

static int s3508_read_touch(struct s3508_data *ts)
{
	u8 att_buf[2];
	u8 data[S3508_MAX_CONTACTS * S3508_CONTACT_SIZE];
	u16 object_attention;
	unsigned int i;
	int ret;

	ret = s3508_set_page(ts, S3508_PAGE_0);
	if (ret < 0)
		return ret;

	/* 先读 F01，部分固件需要这样清锁存，INT 才会释放。 */
	s3508_read_f01_status(ts);

	ret = s3508_read_block(ts, ts->f12.data_base + S3508_F12_OBJECT_ATTENTION,
			       att_buf, sizeof(att_buf));
	if (ret < 0)
		return ret;

	/* object_attention 低 10 bit 分别对应最多 10 个 finger object。 */
	object_attention = att_buf[0] | (att_buf[1] << 8);
	object_attention &= S3508_F12_OBJECT_MASK;

	if (!object_attention) {
		s3508_report_release(ts);
		return 0;
	}

	ret = s3508_read_block(ts, ts->f12.data_base, data,
			       ts->max_contacts * S3508_CONTACT_SIZE);
	if (ret < 0)
		return ret;

	for (i = 0; i < ts->max_contacts; i++) {
		const u8 *p = &data[i * S3508_CONTACT_SIZE];
		bool active = object_attention & BIT(i);
		u16 x, y;
		u8 pressure;
		u8 width;

		/* 每点 8 字节。第 0 字节是 object type/status，0 表示无效。 */
		if (!active || !p[0]) {
			input_mt_slot(ts->input, i);
			input_mt_report_slot_state(ts->input, MT_TOOL_FINGER, false);
			continue;
		}

		/* 坐标格式与 OnePlus/Oppo S3508 驱动、本项目 MCU 端代码一致。 */
		x = ((p[2] & 0x0f) << 8) | p[1];
		y = ((p[4] & 0x0f) << 8) | p[3];
		pressure = p[5];
		width = max_t(u8, p[6] & 0x0f, p[7] & 0x0f);

		input_mt_slot(ts->input, i);
		input_mt_report_slot_state(ts->input, MT_TOOL_FINGER, true);
		touchscreen_report_pos(ts->input, &ts->prop, x, y, true);
		input_report_abs(ts->input, ABS_MT_PRESSURE, pressure);
		input_report_abs(ts->input, ABS_MT_TOUCH_MAJOR, width ? width : 1);
	}

	input_mt_sync_frame(ts->input);
	input_sync(ts->input);

	/* 读完 F12 后再清一次 F01，兼容 level-low INT 不自动释放的固件。 */
	s3508_read_f01_status(ts);

	return 0;
}

static irqreturn_t s3508_irq_thread(int irq, void *dev_id)
{
	struct s3508_data *ts = dev_id;

	mutex_lock(&ts->lock);
	if (!ts->suspended)
		s3508_read_touch(ts);
	mutex_unlock(&ts->lock);

	return IRQ_HANDLED;
}

static int s3508_input_init(struct s3508_data *ts)
{
	struct device *dev = &ts->client->dev;
	struct input_dev *input;
	int ret;

	input = devm_input_allocate_device(dev);
	if (!input)
		return -ENOMEM;

	input->name = "Synaptics S3508 Touchscreen";
	input->id.bustype = BUS_I2C;
	input->dev.parent = dev;

	input_set_capability(input, EV_KEY, BTN_TOUCH);
	/* 默认物理坐标为竖屏 1080x1920；DTS 可用 touchscreen-* 属性覆盖。 */
	input_set_abs_params(input, ABS_MT_POSITION_X, 0, 1080, 0, 0);
	input_set_abs_params(input, ABS_MT_POSITION_Y, 0, 1920, 0, 0);
	input_set_abs_params(input, ABS_MT_PRESSURE, 0, 255, 0, 0);
	input_set_abs_params(input, ABS_MT_TOUCH_MAJOR, 0, 15, 0, 0);

	touchscreen_parse_properties(input, true, &ts->prop);

	ret = input_mt_init_slots(input, ts->max_contacts,
				  INPUT_MT_DIRECT | INPUT_MT_DROP_UNUSED);
	if (ret)
		return ret;

	ts->input = input;

	return input_register_device(input);
}

static int s3508_get_optional_regulator(struct device *dev, const char *id,
					       struct regulator **regulator)
{
	struct regulator *reg;

	reg = devm_regulator_get_optional(dev, id);
	if (IS_ERR(reg)) {
		if (PTR_ERR(reg) == -ENODEV) {
			*regulator = NULL;
			return 0;
		}

		return PTR_ERR(reg);
	}

	*regulator = reg;
	return 0;
}

static int s3508_probe(struct i2c_client *client)
{
	struct device *dev = &client->dev;
	struct s3508_data *ts;
	u32 max_contacts;
	int ret;

	if (!i2c_check_functionality(client->adapter, I2C_FUNC_I2C))
		return -ENXIO;

	if (!client->irq)
		return dev_err_probe(dev, -EINVAL, "IRQ is required\n");

	ts = devm_kzalloc(dev, sizeof(*ts), GFP_KERNEL);
	if (!ts)
		return -ENOMEM;

	ts->client = client;
	mutex_init(&ts->lock);
	i2c_set_clientdata(client, ts);

	/* 未配置时按 S3508/F12 attention 的低 10 bit 处理最多 10 点。 */
	if (device_property_read_u32(dev, "synaptics,max-contacts", &max_contacts))
		max_contacts = S3508_MAX_CONTACTS;
	ts->max_contacts = clamp_val(max_contacts, 1, S3508_MAX_CONTACTS);

	ret = s3508_get_optional_regulator(dev, "vdd", &ts->vdd);
	if (ret)
		return dev_err_probe(dev, ret, "Failed to get vdd\n");

	ret = s3508_get_optional_regulator(dev, "vio", &ts->vio);
	if (ret)
		return dev_err_probe(dev, ret, "Failed to get vio\n");

	ts->reset_gpio = devm_gpiod_get_optional(dev, "reset", GPIOD_OUT_LOW);
	if (IS_ERR(ts->reset_gpio))
		return dev_err_probe(dev, PTR_ERR(ts->reset_gpio),
				     "Failed to get reset GPIO\n");

	ret = s3508_hw_power_on(ts);
	if (ret)
		return dev_err_probe(dev, ret, "Failed to power on\n");

	ret = s3508_init_device(ts);
	if (ret)
		goto err_power_off;

	ret = s3508_input_init(ts);
	if (ret)
		goto err_power_off;

	ret = devm_request_threaded_irq(dev, client->irq, NULL, s3508_irq_thread,
					 IRQF_ONESHOT, client->name, ts);
	if (ret)
		goto err_power_off;

	/* 注册 IRQ 后主动读一次，处理 probe 前已经拉低的 INT。 */
	mutex_lock(&ts->lock);
	s3508_read_touch(ts);
	mutex_unlock(&ts->lock);

	return 0;

err_power_off:
	s3508_hw_power_off(ts);
	return ret;
}

static void s3508_remove(struct i2c_client *client)
{
	struct s3508_data *ts = i2c_get_clientdata(client);

	/* 先释放 IRQ，确保断电后不会再进入 I2C 读写路径。 */
	devm_free_irq(&client->dev, client->irq, ts);
	s3508_hw_power_off(ts);
}

static int s3508_suspend(struct device *dev)
{
	struct i2c_client *client = to_i2c_client(dev);
	struct s3508_data *ts = i2c_get_clientdata(client);

	disable_irq(client->irq);

	mutex_lock(&ts->lock);
	ts->suspended = true;
	s3508_report_release(ts);
	s3508_hw_power_off(ts);
	mutex_unlock(&ts->lock);

	return 0;
}

static int s3508_resume(struct device *dev)
{
	struct i2c_client *client = to_i2c_client(dev);
	struct s3508_data *ts = i2c_get_clientdata(client);
	int ret;

	mutex_lock(&ts->lock);
	ret = s3508_hw_power_on(ts);
	if (!ret)
		ret = s3508_init_device(ts);
	if (ret) {
		/* 重新初始化失败时保持 suspended，IRQ 线程不会继续读 I2C。 */
		s3508_hw_power_off(ts);
	} else {
		ts->suspended = false;
	}
	enable_irq(client->irq);
	mutex_unlock(&ts->lock);

	return ret;
}

static DEFINE_SIMPLE_DEV_PM_OPS(s3508_pm_ops, s3508_suspend, s3508_resume);

static const struct of_device_id s3508_of_match[] = {
	{ .compatible = "synaptics,s3508" },
	{ }
};
MODULE_DEVICE_TABLE(of, s3508_of_match);

static const struct i2c_device_id s3508_id[] = {
	{ "s3508" },
	{ }
};
MODULE_DEVICE_TABLE(i2c, s3508_id);

static struct i2c_driver s3508_driver = {
	.driver = {
		.name = S3508_NAME,
		.of_match_table = s3508_of_match,
		.pm = pm_sleep_ptr(&s3508_pm_ops),
	},
	.probe = s3508_probe,
	.remove = s3508_remove,
	.id_table = s3508_id,
};
module_i2c_driver(s3508_driver);

MODULE_DESCRIPTION("Synaptics S3508 RMI4 touchscreen driver");
MODULE_LICENSE("GPL");
