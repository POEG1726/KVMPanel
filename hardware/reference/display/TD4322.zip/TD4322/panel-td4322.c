// SPDX-License-Identifier: GPL-2.0-only
/*
 * DRM panel driver for TD4322 command mode DSI panel.
 *
 * Converted from SDK/apps/panel_link_dev/rk628 td4322 panel profile.
 */

#include <linux/backlight.h>
#include <linux/delay.h>
#include <linux/gpio/consumer.h>
#include <linux/module.h>
#include <linux/of.h>

#include <video/mipi_display.h>

#include <drm/drm_mipi_dsi.h>
#include <drm/drm_modes.h>
#include <drm/drm_panel.h>

struct td4322_panel {
	struct drm_panel panel;
	struct mipi_dsi_device *dsi;
	struct gpio_desc *reset_gpio;
	struct gpio_desc *enable_gpio;
	struct gpio_desc *swire_gpio;
};

static inline struct td4322_panel *to_td4322_panel(struct drm_panel *panel)
{
	return container_of(panel, struct td4322_panel, panel);
}

static void td4322_generic_write(struct mipi_dsi_multi_context *dsi_ctx,
					 const void *data, size_t len)
{
	ssize_t ret;

	if (dsi_ctx->accum_err)
		return;

	ret = mipi_dsi_generic_write(dsi_ctx->dsi, data, len);
	if (ret < 0)
		dsi_ctx->accum_err = ret;
}

#define td4322_generic_write_seq(ctx, seq...) do { \
	static const u8 d[] = { seq }; \
	td4322_generic_write((ctx), d, ARRAY_SIZE(d)); \
} while (0)

static void td4322_power_on(struct td4322_panel *ctx)
{
	int i;

	if (ctx->enable_gpio)
		gpiod_set_value_cansleep(ctx->enable_gpio, 1);

	if (ctx->swire_gpio) {
		/* Pull low to shutdown and reset the SGM3851A */
		gpiod_set_value_cansleep(ctx->swire_gpio, 0);
		usleep_range(1000, 2000);
		
		/* tINIT: 300 to 400 us */
		gpiod_set_value_cansleep(ctx->swire_gpio, 1);
		usleep_range(300, 400);

		/*
		 * SGM3851A Voltage Programming via SWIRE (CTRL pin)
		 * Pulse requirements:
		 * tLOW: 2 to 25 us
		 * tHIGH: 2 to 25 us
		 * tSTORE: 30 to 80 us (wait > 80us after pulses)
		 *
		 * Target Voltages:
		 * VELVSS (VO2): -4.0V -> 15 pulses
		 * VAVDD  (VO3):  7.6V -> 43 pulses
		 * VELVDD (VO1):  4.6V -> 0 pulses (default)
		 */

		/* Program VELVSS (VO2) to -4.0V: 15 pulses */
		for (i = 0; i < 15; i++) {
			gpiod_set_value_cansleep(ctx->swire_gpio, 0);
			usleep_range(10, 20);
			gpiod_set_value_cansleep(ctx->swire_gpio, 1);
			usleep_range(10, 20);
		}
		/* Wait tSTORE to accept data */
		usleep_range(100, 150);

		/* Program VAVDD (VO3) to 7.6V: 43 pulses */
		for (i = 0; i < 43; i++) {
			gpiod_set_value_cansleep(ctx->swire_gpio, 0);
			usleep_range(10, 20);
			gpiod_set_value_cansleep(ctx->swire_gpio, 1);
			usleep_range(10, 20);
		}
		/* Wait tSTORE to accept data */
		usleep_range(100, 150);
	}

	gpiod_set_value_cansleep(ctx->reset_gpio, 1);
	msleep(120);
	gpiod_set_value_cansleep(ctx->reset_gpio, 0);
	msleep(120);
}

static void td4322_power_off(struct td4322_panel *ctx)
{
	msleep(120);
	gpiod_set_value_cansleep(ctx->reset_gpio, 1);
	usleep_range(10000, 11000);

	if (ctx->swire_gpio)
		gpiod_set_value_cansleep(ctx->swire_gpio, 0);

	if (ctx->enable_gpio) {
		gpiod_set_value_cansleep(ctx->enable_gpio, 0);
		msleep(120);
	}
}

static int td4322_panel_on(struct mipi_dsi_device *dsi)
{
	struct mipi_dsi_multi_context dsi_ctx = { .dsi = dsi };

	td4322_generic_write_seq(&dsi_ctx, 0xf0, 0x5a, 0x5a, 0x00);
	td4322_generic_write_seq(&dsi_ctx, 0xfc, 0x5a, 0x5a, 0x00);
	td4322_generic_write_seq(&dsi_ctx, 0xf3, 0x01, 0x00);

	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, MIPI_DCS_EXIT_SLEEP_MODE, 0x00);
	mipi_dsi_msleep(&dsi_ctx, 20);

	td4322_generic_write_seq(&dsi_ctx, 0xf0, 0x5a, 0x5a);
	td4322_generic_write_seq(&dsi_ctx, 0xcc, 0x54, 0x8a);
	td4322_generic_write_seq(&dsi_ctx, 0xb0, 0x04);
	td4322_generic_write_seq(&dsi_ctx, 0xb6, 0x13);
	td4322_generic_write_seq(&dsi_ctx, 0xf0, 0xa5, 0xa5);

	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, MIPI_DCS_SET_TEAR_ON, 0x00);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, MIPI_DCS_WRITE_CONTROL_DISPLAY, 0x20);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, MIPI_DCS_SET_DISPLAY_BRIGHTNESS, 0x00);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x57, 0x40);
	mipi_dsi_msleep(&dsi_ctx, 120);

	td4322_generic_write_seq(&dsi_ctx, 0xfc, 0x5a, 0x5a);
	td4322_generic_write_seq(&dsi_ctx, 0xb0, 0x01);
	td4322_generic_write_seq(&dsi_ctx, 0xd2, 0x20);

	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, MIPI_DCS_SET_DISPLAY_ON, 0x00);
	mipi_dsi_msleep(&dsi_ctx, 120);

	return dsi_ctx.accum_err;
}

static int td4322_panel_prepare(struct drm_panel *panel)
{
	struct td4322_panel *ctx = to_td4322_panel(panel);
	int ret;

	td4322_power_on(ctx);

	ret = td4322_panel_on(ctx->dsi);
	if (ret < 0)
		td4322_power_off(ctx);

	return ret;
}

static int td4322_panel_unprepare(struct drm_panel *panel)
{
	struct td4322_panel *ctx = to_td4322_panel(panel);

	td4322_power_off(ctx);

	return 0;
}

static int td4322_panel_disable(struct drm_panel *panel)
{
	struct td4322_panel *ctx = to_td4322_panel(panel);
	struct mipi_dsi_device *dsi = ctx->dsi;
	struct mipi_dsi_multi_context dsi_ctx = { .dsi = dsi };

	mipi_dsi_dcs_set_display_off_multi(&dsi_ctx);
	mipi_dsi_msleep(&dsi_ctx, 10);
	mipi_dsi_dcs_enter_sleep_mode_multi(&dsi_ctx);
	mipi_dsi_msleep(&dsi_ctx, 150);

	return dsi_ctx.accum_err;
}

static const struct drm_display_mode td4322_panel_mode = {
	.clock = 140640,
	.hdisplay = 1080,
	.hsync_start = 1080 + 140,
	.hsync_end = 1080 + 140 + 12,
	.htotal = 1080 + 140 + 12 + 70,
	.vdisplay = 1920,
	.vsync_start = 1920 + 16,
	.vsync_end = 1920 + 16 + 5,
	.vtotal = 1920 + 16 + 5 + 16,
	.flags = DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC,
	.width_mm = 68,
	.height_mm = 121,
};

static int td4322_panel_get_modes(struct drm_panel *panel,
					 struct drm_connector *connector)
{
	struct drm_display_mode *mode;

	mode = drm_mode_duplicate(connector->dev, &td4322_panel_mode);
	if (!mode)
		return -ENOMEM;

	drm_mode_set_name(mode);

	mode->type = DRM_MODE_TYPE_DRIVER | DRM_MODE_TYPE_PREFERRED;
	connector->display_info.width_mm = mode->width_mm;
	connector->display_info.height_mm = mode->height_mm;
	drm_mode_probed_add(connector, mode);

	return 1;
}

static const struct drm_panel_funcs td4322_panel_funcs = {
	.prepare = td4322_panel_prepare,
	.unprepare = td4322_panel_unprepare,
	.disable = td4322_panel_disable,
	.get_modes = td4322_panel_get_modes,
};

static int td4322_panel_bl_update_status(struct backlight_device *bl)
{
	struct mipi_dsi_device *dsi = bl_get_data(bl);
	u8 brightness = backlight_get_brightness(bl);
	u8 ctrl = 0x20;
	int ret;

	ret = mipi_dsi_dcs_write(dsi, MIPI_DCS_WRITE_CONTROL_DISPLAY,
				  &ctrl, sizeof(ctrl));
	if (ret < 0)
		return ret;

	ret = mipi_dsi_dcs_write(dsi, MIPI_DCS_SET_DISPLAY_BRIGHTNESS,
				  &brightness, sizeof(brightness));
	if (ret < 0)
		return ret;

	return 0;
}

static int td4322_panel_bl_get_brightness(struct backlight_device *bl)
{
	struct mipi_dsi_device *dsi = bl_get_data(bl);
	u8 brightness;
	int ret;

	ret = mipi_dsi_dcs_read(dsi, MIPI_DCS_GET_DISPLAY_BRIGHTNESS,
				&brightness, sizeof(brightness));
	if (ret < 0)
		return ret;

	return brightness;
}

static const struct backlight_ops td4322_panel_bl_ops = {
	.update_status = td4322_panel_bl_update_status,
	.get_brightness = td4322_panel_bl_get_brightness,
};

static struct backlight_device *td4322_panel_create_backlight(struct mipi_dsi_device *dsi)
{
	struct device *dev = &dsi->dev;
	const struct backlight_properties props = {
		.type = BACKLIGHT_RAW,
		.brightness = 184,
		.max_brightness = 255,
	};

	return devm_backlight_device_register(dev, dev_name(dev), dev, dsi,
					      &td4322_panel_bl_ops, &props);
}

static int td4322_panel_probe(struct mipi_dsi_device *dsi)
{
	struct device *dev = &dsi->dev;
	struct td4322_panel *ctx;
	int ret;

	ctx = devm_drm_panel_alloc(dev, struct td4322_panel, panel,
				   &td4322_panel_funcs,
				   DRM_MODE_CONNECTOR_DSI);
	if (IS_ERR(ctx))
		return PTR_ERR(ctx);

	ctx->reset_gpio = devm_gpiod_get(dev, "reset", GPIOD_OUT_HIGH);
	if (IS_ERR(ctx->reset_gpio))
		return dev_err_probe(dev, PTR_ERR(ctx->reset_gpio),
				     "Failed to get reset-gpios\n");

	ctx->enable_gpio = devm_gpiod_get_optional(dev, "enable", GPIOD_OUT_LOW);
	if (IS_ERR(ctx->enable_gpio))
		return dev_err_probe(dev, PTR_ERR(ctx->enable_gpio),
				     "Failed to get enable-gpios\n");

	ctx->swire_gpio = devm_gpiod_get_optional(dev, "swire", GPIOD_OUT_LOW);
	if (IS_ERR(ctx->swire_gpio))
		return dev_err_probe(dev, PTR_ERR(ctx->swire_gpio),
				     "Failed to get swire-gpios\n");

	ctx->dsi = dsi;
	mipi_dsi_set_drvdata(dsi, ctx);

	dsi->lanes = 4;
	dsi->format = MIPI_DSI_FMT_RGB888;
	dsi->mode_flags = MIPI_DSI_MODE_LPM;

	ctx->panel.prepare_prev_first = true;

	ctx->panel.backlight = td4322_panel_create_backlight(dsi);
	if (IS_ERR(ctx->panel.backlight))
		return dev_err_probe(dev, PTR_ERR(ctx->panel.backlight),
				     "Failed to create backlight\n");

	drm_panel_add(&ctx->panel);

	ret = mipi_dsi_attach(dsi);
	if (ret < 0) {
		dev_err(dev, "Failed to attach to DSI host: %d\n", ret);
		drm_panel_remove(&ctx->panel);
		return ret;
	}

	return 0;
}

static void td4322_panel_remove(struct mipi_dsi_device *dsi)
{
	struct td4322_panel *ctx = mipi_dsi_get_drvdata(dsi);
	int ret;

	ret = mipi_dsi_detach(dsi);
	if (ret < 0)
		dev_err(&dsi->dev, "Failed to detach from DSI host: %d\n", ret);

	drm_panel_remove(&ctx->panel);
}

static const struct of_device_id td4322_panel_of_match[] = {
	{ .compatible = "synaptics,td4322" },
	{ /* sentinel */ }
};
MODULE_DEVICE_TABLE(of, td4322_panel_of_match);

static struct mipi_dsi_driver td4322_panel_driver = {
	.probe = td4322_panel_probe,
	.remove = td4322_panel_remove,
	.driver = {
		.name = "panel-td4322",
		.of_match_table = td4322_panel_of_match,
	},
};
module_mipi_dsi_driver(td4322_panel_driver);

MODULE_DESCRIPTION("DRM driver for TD4322 command mode DSI panel");
MODULE_LICENSE("GPL");
