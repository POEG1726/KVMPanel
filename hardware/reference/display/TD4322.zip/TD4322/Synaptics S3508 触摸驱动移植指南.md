# Synaptics S3508 触摸驱动移植指南


## 驱动能力

`synaptics-s3508.c` 实现内容：

- I2C 触摸设备 probe/remove。
- 可选 `vdd` / `vio` regulator 供电。
- 可选 `reset-gpios` 复位控制。
- RMI4 page 0 PDT 扫描。
- F01 normal mode 配置和中断使能。
- F12 多点触摸数据读取。
- Linux input Type-B multitouch slot 上报。
- `touchscreen-*` 标准属性解析，用于坐标尺寸、交换轴和翻转轴。
- suspend/resume 断电和重新初始化。

> [!WARNING]
> **固件升级（OTA）能力提示**：该轻量化驱动移除了原厂驱动中臃肿的 F34（固件刷写）和 F54（测试诊断）模块，仅保留了基础报点功能。如果出厂的 S3508 IC 是未烧录固件的“白片”或固件损坏，使用该驱动将无法正常初始化。必须提前通过烧录治具或其它完整驱动刷入固件。


## 完整版与简化版驱动的选择

本项目提供了两套 S3508 驱动，分别应对不同的产品化阶段：

1. **简化版驱动 (`synaptics-s3508.c`)**
   - **特点**：去除了所有冗余原厂逻辑，代码量仅 500 多行，纯 Mainline I2C Input 风格，移植排错极其容易。
   - **推荐场景**：项目点亮初期、简单的交互式终端、智能硬件等只需基础多点触控、不需要休眠唤醒手势的设备。

2. **完整版驱动 (`synaptics-s3508-full.c`)**
   - **新增功能**：基于手机厂商级量产驱动剥离而来，额外支持 **F34（固件刷写检查）**、**F51（黑屏手势，如双击唤醒、画 V/O/W/M）**、**F54（工厂产测及短路测试）**、**手套模式**、**边缘防误触**等高级特性。
   - **推荐场景**：商用级复杂安卓/Linux设备、存在“白片”（未烧录固件）需要开机自动 OTA 刷写的情况、或者业务强依赖黑屏手势唤醒的场景。

## 硬件连接

默认硬件连接：

- I2C 7-bit 地址：`0x20`。
- 中断：低有效，建议 DTS 使用下降沿或低电平触发。
- reset GPIO：可选。如果板上未连接 reset，DTS 中不要填写 `reset-gpios`。
- 供电：`vdd` 和 `vio` 均为可选 supply；如果平台已经常供电，也可以不填。

默认坐标范围：

- X：`0..1080`
- Y：`0..1920`
- 最大触点数：`10`

如果产品最终需要横屏 `1920x1080` 或需要翻转方向，请优先通过 DTS 的 `touchscreen-*` 属性处理，不建议直接改触点解析公式。

## 文件放置

建议路径：

`drivers/input/touchscreen/synaptics-s3508.c`

`drivers/input/touchscreen/Kconfig` 增加：

```kconfig
config TOUCHSCREEN_SYNAPTICS_S3508
	tristate "Synaptics S3508 touchscreen"
	depends on I2C
	select INPUT_MT
	help
	  Say Y here if you have a Synaptics S3508 RMI4 I2C touchscreen.
```

`drivers/input/touchscreen/Makefile` 增加：

```make
obj-$(CONFIG_TOUCHSCREEN_SYNAPTICS_S3508) += synaptics-s3508.o
```

## DTS 示例

基础示例：

```dts
#include <dt-bindings/interrupt-controller/irq.h>
#include <dt-bindings/gpio/gpio.h>

&i2cX {
	status = "okay";
	clock-frequency = <400000>; /* 推荐配置 400kHz 快速模式，降低大批量报点数据的读取延迟 */

	touchscreen@20 {
		compatible = "synaptics,s3508";
		reg = <0x20>;
		
		/* 引脚复用配置：务必确保 I2C、INT、RESET 引脚已切换至对应功能，尤其是 INT 需配置内部上拉 */
		pinctrl-names = "default";
		pinctrl-0 = <&ts_int_pin &ts_reset_pin>;

		interrupt-parent = <&gpioX>;
		interrupts = <Y IRQ_TYPE_EDGE_FALLING>; /* 如果没有外部上拉，必须在 pinctrl 中配置内部上拉 */

		vdd-supply = <&vdd_3v0>;
		vio-supply = <&vcc_i2c_1v8>;

		touchscreen-size-x = <1080>;
		touchscreen-size-y = <1920>;
	};
};
```

带 reset GPIO 的示例：

```dts
touchscreen@20 {
	compatible = "synaptics,s3508";
	reg = <0x20>;

	pinctrl-names = "default";
	pinctrl-0 = <&ts_int_pin &ts_reset_pin>;

	interrupt-parent = <&gpioX>;
	interrupts = <Y IRQ_TYPE_EDGE_FALLING>;

	reset-gpios = <&gpioX Z GPIO_ACTIVE_LOW>;

	vdd-supply = <&vdd_3v0>;
	vio-supply = <&vcc_i2c_1v8>;

	touchscreen-size-x = <1080>;
	touchscreen-size-y = <1920>;
	synaptics,max-contacts = <10>;
};
```

横屏或方向不一致时，可按实际情况增加：

```dts
touchscreen-swapped-x-y;
touchscreen-inverted-x;
touchscreen-inverted-y;
```

## 重点寄存器

S3508 按 Synaptics RMI4 方式访问。驱动只依赖 page 0 的 F01 和 F12。

关键寄存器/区域：

- `0xff`：RMI page select，写 `0x00` 选择 page 0。
- `0xe9..0x05`：PDT，Product Descriptor Table，每 6 字节一个 function descriptor。
- `F01`：RMI device control/status function。
- `F12`：2D touch function。
- `F01 Ctrl0`：驱动写 `0x80`，让 IC 进入 normal operation。
- `F01 Ctrl1`：驱动写 `0x7f`，使能绝对坐标相关中断。
- `F01 Data`：读取后用于清除锁存中断状态。
- `F12 Data + 0x03`：object attention，两字节，低 10 bit 对应 slot0..slot9 是否有触点数据。
- `F12 Data`：触点数据起始地址，每个触点 8 字节。

## 初始化流程

驱动 probe 后执行：

1. 获取 I2C client 和 IRQ。
2. 获取可选 regulator：`vdd`、`vio`。
3. 获取可选 reset GPIO：`reset-gpios`。
4. 上电：enable `vdd`，enable `vio`。
5. 如果存在 reset GPIO：assert reset 10ms，release reset 后等待 100ms。
6. 写 `0xff = 0x00`，切到 RMI page 0。
7. 扫描 PDT，找到 F01/F12 的 query/cmd/ctrl/data base。
8. 写 `F01 Ctrl0 = 0x80`。
9. 读取 `F01 Data` 清除旧中断。
10. 写 `F01 Ctrl1 = 0x7f` 使能触摸中断。
11. 注册 threaded IRQ。
12. 主动读一次触摸数据，处理 probe 前已经拉低的 INT。

## 触点数据格式

驱动先读取：

```c
object_attention = read16(F12_DATA_BASE + 0x03) & 0x03ff;
```

如果 `object_attention == 0`，驱动释放所有 multitouch slot。

如果存在触点，驱动从 `F12_DATA_BASE` 读取 `max_contacts * 8` 字节。

每个触点 8 字节：

```c
p = &data[i * 8];

status = p[0];
x = ((p[2] & 0x0f) << 8) | p[1];
y = ((p[4] & 0x0f) << 8) | p[3];
pressure = p[5];
width_x = p[6] & 0x0f;
width_y = p[7] & 0x0f;
```

slot 有效条件：

```c
(object_attention & BIT(i)) && status != 0
```

坐标通过 `touchscreen_report_pos()` 上报，因此 DTS 中的 `touchscreen-swapped-x-y`、`touchscreen-inverted-x`、`touchscreen-inverted-y` 会自动生效。

## 中断处理

驱动使用 threaded IRQ：

```c
devm_request_threaded_irq(dev, client->irq, NULL, s3508_irq_thread,
			 IRQF_ONESHOT, client->name, ts);
```

IRQ 线程流程：

1. 加锁。
2. 如果未 suspend，执行 `s3508_read_touch()`。
3. 读 `F01 Data` 清中断。
4. 读 `F12 object attention`。
5. 读 F12 触点块并上报 input。
6. 再读一次 `F01 Data`，兼容低有效 INT 不释放的固件。
7. 解锁。

如果平台中断是低电平触发，可把 DTS interrupt type 改成：

```dts
interrupts = <Y IRQ_TYPE_LEVEL_LOW>;
```

但需要确认中断控制器和电平释放行为正常。

## 坐标适配

默认 `synaptics-s3508.c` 中设置：

```c
input_set_abs_params(input, ABS_MT_POSITION_X, 0, 1080, 0, 0);
input_set_abs_params(input, ABS_MT_POSITION_Y, 0, 1920, 0, 0);
```

实际产品可以通过 DTS 覆盖：

```dts
touchscreen-size-x = <1080>;
touchscreen-size-y = <1920>;
```

如果触摸方向和显示方向不一致，优先尝试以下组合：

```dts
touchscreen-swapped-x-y;
touchscreen-inverted-x;
touchscreen-inverted-y;
```

如果触摸存在小范围的噪点或抖动，可以通过以下属性在 DTS 中增加去抖（死区），避免修改驱动代码：

```dts
touchscreen-fuzz-x = <5>;
touchscreen-fuzz-y = <5>;
```

移植时建议先使用 `evtest` 或 `libinput debug-events` 验证原始触点方向，再决定 DTS 坐标属性。

## 移植检查清单

1. I2C 总线已启用，设备地址为 `0x20`。
2. DTS `compatible = "synaptics,s3508"`。
3. DTS `reg = <0x20>`。
4. IRQ GPIO 方向和触发类型正确。
5. 如果板上 reset 接线存在，`reset-gpios` 极性正确。
6. 如果电源由内核控制，`vdd-supply` 和 `vio-supply` 名称正确。
7. 内核启用 `CONFIG_INPUT`、`CONFIG_INPUT_EVDEV`、`CONFIG_INPUT_MT`、`CONFIG_I2C`。
8. Kconfig 启用 `CONFIG_TOUCHSCREEN_SYNAPTICS_S3508`。
9. 启动日志能看到 I2C 设备 probe 成功。
10. `/proc/interrupts` 中触摸 IRQ 计数会随触摸变化。
11. `/dev/input/eventX` 能通过 `evtest` 看到 `ABS_MT_POSITION_X/Y`。

## 常见问题

### probe 失败，找不到 F01/F12

检查项：

- I2C 地址是否为 `0x20`。
- 供电是否已经打开。
- reset 是否被一直拉住。
- I2C pinmux 是否正确。
- 逻辑分析仪确认是否能读到 `0xff` page select 和 PDT 区域。

### 有中断但没有坐标

检查项：

- `F01 Ctrl1 = 0x7f` 是否写入成功。
- `F12 Data + 0x03` 读出的 object attention 是否非零。
- IRQ 触发类型是否正确。
- INT 是否为低有效且能释放。

### 坐标方向不对

优先调整 DTS：

```dts
touchscreen-swapped-x-y;
touchscreen-inverted-x;
touchscreen-inverted-y;
```

不要优先修改 `x/y` 解析公式，除非确认固件数据格式与当前驱动不一致。

### 多指数量不对

默认最多 10 点。可通过 DTS 限制：

```dts
synaptics,max-contacts = <5>;
```

该值不能超过 10。
