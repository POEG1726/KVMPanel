# Synaptics TD4322 屏幕驱动移植指南

## 驱动特性

`panel-td4322.c` 实现内容：
- DRM panel driver for TD4322 command mode DSI panel.
- 支持 GPIO 电源控制和硬件复位。
- 支持基于 MIPI DCS 标准指令 (`0x51`) 的屏幕内置亮度调节（无需外部 PWM）。

## 文件放置与编译配置

建议路径：
`drivers/gpu/drm/panel/panel-td4322.c`

在 `drivers/gpu/drm/panel/Kconfig` 中增加：
```kconfig
config DRM_PANEL_TD4322
	tristate "Synaptics TD4322 command mode DSI panel"
	depends on OF
	depends on DRM_MIPI_DSI
	depends on BACKLIGHT_CLASS_DEVICE
	help
	  Say Y here if you want to enable support for Synaptics TD4322 panel.
```

在 `drivers/gpu/drm/panel/Makefile` 中增加：
```make
obj-$(CONFIG_DRM_PANEL_TD4322) += panel-td4322.o
```

## 硬件连接及供电

- **屏幕 GPIO 电压**：`1.8V`。请注意做好电平转换，电源 IC 的控制引脚兼容 `1.8V` 和 `3.3V` 两种电压。
- **默认供电要求**：
  - **VAVDD**：`7.6V / 55mA`
  - **VELVDD**：`4.6V / 300mA`
  - **VELVSS**：`-4.0V / 300mA`
  - VELVSS可以根据屏幕功耗上下浮动调整，最好不要超过-4.8v
- 屏幕EN_AVDD连接到电源IC的EN_VO3控制VAVDD开启
- 屏幕EN_VDD_VSS_LCD连接到电源IC的CTRL控制电压

屏幕供电常采用 SGM3851A（或同类芯片）。屏幕供电默认可由屏幕自行控制，但在调试过程中最好保留使用 SOC 的 GPIO 控制以方便排查问题。

### TE (Tearing Effect) 防撕裂信号
> [!IMPORTANT]
> 该屏幕工作在 **CMD 模式 (Command Mode)**，通常极度依赖 **TE 信号** 来同步主控和屏幕刷新的 VSYNC，否则移动画面时可能出现撕裂（Tearing）。
> 硬件设计上请确认是否预留了专用的 TE 物理引脚连线，还是依赖 MIPI 协议底层的 TE 触发。如果是物理连线，DTS 往往需要额外配置 `te-gpios`，驱动中也需要做相应处理。这对排查 UI 撕裂问题至关重要。

## 上电时序

> [!IMPORTANT]
> 请注意，该屏幕运行在 **CMD 模式 (Command Mode)** 下，需要注意休眠退出和初始化序列的发送。

参考上电时序如下：
1. 打开 LCD `3.3V` 和 `1.8V` 供电
2. 等待 10ms
3. 打开 VELVDD、VELVSS、VAVDD 并且调整至对应的电压（如果由屏幕控制则无需主动调整，屏幕自动控制的情况下可能出现调压误差，最好手动测量确认）
4. 等待 10ms
5. 复位管脚（Reset）拉低 `>20us`，再拉高
6. 等待 10ms
7. 发送 MIPI 初始化序列

对应的代码实现可参考 `td4322_power_on`：

```c
static void td4322_power_on(struct td4322_panel *ctx)
{
	int i;

	if (ctx->enable_gpio)
		gpiod_set_value_cansleep(ctx->enable_gpio, 1);

	if (ctx->swire_gpio) {
		/* Pull low to shutdown and reset the SGM3851A */
		gpiod_set_value_cansleep(ctx->swire_gpio, 0);
		usleep_range(1000, 2000);
		
		/* tINIT: 300 to 400 us */
		gpiod_set_value_cansleep(ctx->swire_gpio, 1);
		usleep_range(300, 400);

		/*
		 * SGM3851A Voltage Programming via SWIRE (CTRL pin)
		 * Target Voltages:
		 * VELVSS (VO2): -4.0V -> 15 pulses
		 * VAVDD  (VO3):  7.6V -> 43 pulses
		 * VELVDD (VO1):  4.6V -> 0 pulses (default)
		 */

		/* Program VELVSS (VO2) to -4.0V: 15 pulses */
		for (i = 0; i < 15; i++) {
			gpiod_set_value_cansleep(ctx->swire_gpio, 0);
			usleep_range(10, 20);
			gpiod_set_value_cansleep(ctx->swire_gpio, 1);
			usleep_range(10, 20);
		}
		/* Wait tSTORE to accept data */
		usleep_range(100, 150);

		/* Program VAVDD (VO3) to 7.6V: 43 pulses */
		for (i = 0; i < 43; i++) {
			gpiod_set_value_cansleep(ctx->swire_gpio, 0);
			usleep_range(10, 20);
			gpiod_set_value_cansleep(ctx->swire_gpio, 1);
			usleep_range(10, 20);
		}
		/* Wait tSTORE to accept data */
		usleep_range(100, 150);
	}

	gpiod_set_value_cansleep(ctx->reset_gpio, 1);
	msleep(120);
	gpiod_set_value_cansleep(ctx->reset_gpio, 0);
	msleep(120);
}
```

## DTS 示例

TD4322 屏幕设备通常作为 MIPI DSI 控制器的子节点，参考配置如下：

```dts
&dsi {
	status = "okay";

	panel@0 {
		compatible = "synaptics,td4322";
		reg = <0>;

		/* 硬件复位管脚 (必填) */
		reset-gpios = <&gpioX Y GPIO_ACTIVE_HIGH>;

		/* 屏幕供电使能管脚 (可选) */
		enable-gpios = <&gpioX Z GPIO_ACTIVE_LOW>;

		/* SGM3851A 等电源 IC 控制管脚 (可选) */
		swire-gpios = <&gpioX W GPIO_ACTIVE_LOW>;

		port {
			panel_in: endpoint {
				remote-endpoint = <&dsi_out>;
			};
		};
	};
};
```

## 屏幕时序 (Timing)

默认屏幕时序如下（仅供参考）：

```c
static const struct drm_display_mode td4322_panel_mode = {
	.clock = 140640,
	.hdisplay = 1080,
	.hsync_start = 1080 + 140,
	.hsync_end = 1080 + 140 + 12,
	.htotal = 1080 + 140 + 12 + 70,
	.vdisplay = 1920,
	.vsync_start = 1920 + 16,
	.vsync_end = 1920 + 16 + 5,
	.vtotal = 1920 + 16 + 5 + 16,
	.flags = DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC,
	.width_mm = 68,
	.height_mm = 121,
};
```

> [!WARNING]
> 请根据当前平台的实际情况进行微调。错误的时序和时钟会导致屏幕完全不显示或背光不亮。
> 建议的 MIPI Lane Rate 参考范围为：**900 - 1100 Mbps**。

### MIPI Lane 和 Format 提示
目前在驱动代码 `panel-td4322.c` 中对 MIPI 参数进行了**硬编码**：
```c
dsi->lanes = 4;
dsi->format = MIPI_DSI_FMT_RGB888;
```

## 调试排障指南

如果遇到屏幕不亮、无显示，请按照以下步骤逐步排查：

### 1. 读取状态寄存器
在点亮代码中增加读取以下 DCS 寄存器，如果能读出来非全 0/FF 数据，说明 MIPI 链路、屏幕供电和硬件连接基本满足：

| 寄存器 | 名称 | 长度 | 常用场景及说明 |
| :--- | :--- | :--- | :--- |
| `0x04` | `GET_DISPLAY_ID / RDDID` | 3 bytes | 读显示 ID（部分模组可能返回固定值或无效值） |
| `0x09` | `GET_DISPLAY_STATUS` | 4 bytes | 读显示状态，调试最常用的指令之一 |
| `0x0A` | `GET_POWER_MODE` | 1 byte | 判断 Sleep、Display ON/OFF、Normal/Idle 等状态 |
| `0x0B` | `GET_ADDRESS_MODE` | 1 byte | 读地址扫描方向，对应 MADCTL / address mode |
| `0x0C` | `GET_PIXEL_FORMAT` | 1 byte | 读像素格式，返回与 16/18/24bit RGB 相关的格式设定 |
| `0x0D` | `GET_DISPLAY_MODE` | 1 byte | 读显示模式 |

### 2. 硬件及基础配置排查
如果寄存器**无法读取**或读出全为 `0x00`/`0xFF`：
- 请先排查硬件连线，万用表测量电压值（VAVDD/VELVDD/VELVSS）是否达标。
- 示波器确认 Reset GPIO 状态及上电时序是否符合要求。
- 排查后如果依然不通，尝试微调 `clock` 和 `lane_rate`。

### 3. 显示异常排查
如果屏幕已点亮，但出现**显示偏移、边缘花屏等**现象：
- 请微调时序参数：`hsync_start` / `hsync_end` / `htotal` 和 `vsync_start` / `vsync_end` / `vtotal`。

## 亮度调节

本屏幕支持通过 MIPI DCS 指令调节亮度，亮度调节指令为 `0x51` (Write Display Brightness)，不需要平台外接 PWM 信号控制。
具体可以参考驱动代码中 `td4322_panel_bl_update_status` 的实现：

```c
static int td4322_panel_bl_update_status(struct backlight_device *bl)
{
	// ...
	// 0x20 为 WRITE_CONTROL_DISPLAY
	ret = mipi_dsi_dcs_write(dsi, MIPI_DCS_WRITE_CONTROL_DISPLAY, &ctrl, sizeof(ctrl));
	
	// 0x51 为 SET_DISPLAY_BRIGHTNESS
	ret = mipi_dsi_dcs_write(dsi, MIPI_DCS_SET_DISPLAY_BRIGHTNESS, &brightness, sizeof(brightness));
	// ...
}
```
